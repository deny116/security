package com.example.security.Rental;

public enum RentalStatus {
    NEW,
    ACCEPTED,
    CANCELLED,
    IN_PROGRESS,
    COMPLETED
}







